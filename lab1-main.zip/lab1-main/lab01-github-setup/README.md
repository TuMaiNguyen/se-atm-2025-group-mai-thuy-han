# Lab 01 - Thiết lập môi trường & Quản lý dự án trên GitHub

## Giới thiệu
Đây là bài nộp Lab 01 của môn Nhập môn Công nghệ phần mềm.  
Mục tiêu của Lab này là làm quen với GitHub, Git và cách quản lý dự án.

## Thông tin sinh viên
- Họ tên: [Ghi tên bạn]
- MSSV: [Ghi MSSV của bạn]
- Lớp: [Tên lớp]
- Email: [Email của bạn]

## Nội dung đã thực hiện
- Tạo repository trên GitHub.
- Tạo thư mục `lab01-github-setup`.
- Thêm file `about_me.txt` để giới thiệu bản thân.
- Commit & push các thay đổi lên GitHub.
